﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MeetWagon.Context;
using MeetWagon.Models;

namespace MeetWagon.Controllers
{
    public class HomeController : Controller
    {
        private DataContext db = new DataContext();
        public ActionResult Index()
        {

            List<Wagon> popularWagons = db.Wagons.OrderByDescending(x => x.UserProfiles.Count()).ToList();


            return View(popularWagons);
        }
             
    }
}

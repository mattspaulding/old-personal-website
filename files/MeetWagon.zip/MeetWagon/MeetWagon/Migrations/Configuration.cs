namespace MeetWagon.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using System.Web.Security;
    using WebMatrix.WebData;

    internal sealed class Configuration : DbMigrationsConfiguration<MeetWagon.Context.DataContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(MeetWagon.Context.DataContext context)
        {
            WebSecurity.InitializeDatabaseConnection(
              "DefaultConnection",
              "UserProfile",
              "UserId",
              "UserName", autoCreateTables: true);

            if (!Roles.RoleExists("Administrator"))
                Roles.CreateRole("Administrator");

            if (!WebSecurity.UserExists("matt"))
                WebSecurity.CreateUserAndAccount(
                    "matt",
                    "password"
                    );
            if (!WebSecurity.UserExists("guest"))
                WebSecurity.CreateUserAndAccount(
                    "guest",
                    "password"
                    );

            if (!Roles.GetRolesForUser("matt").Contains("Administrator"))
                Roles.AddUsersToRoles(new[] { "matt" }, new[] { "Administrator" });
        }
    }
}

Please watch the course that accompanies this project.

http://youtu.be/K7zBDHYmBA4

